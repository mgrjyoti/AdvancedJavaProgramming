package com.jspiders.CarDekho_CaseStydy_Hibernate.DTO;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class SearchCarDTO {
 @Id
	 private int id;
	 private String Cname;
	 private String brand;
	 private String flue;
   	private double price;
	public void setFuel_type(String next) {
		// TODO Auto-generated method stub
		
	}

}
