package com.jspiders.CarDekho_CaseStydy_Hibernate.DTO;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;
@Data
@Entity
public class CarDTO {

	@Id
	private  int id;
	private String Cname;
	private String brand;
	private String flue;
	private double price;
	public void setFuel_type(String next) {
	
		
	}
}
