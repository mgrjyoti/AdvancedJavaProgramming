package com.jspiders.CarDekho_CaseStydy_Hibernate.DAO;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.jspiders.CarDekho_CaseStydy_Hibernate.DTO.CarDTO;
import com.jspiders.CarDekho_CaseStydy_Hibernate.DTO.SearchCarDTO;

public class CarMain {

	private static EntityManagerFactory entityManagerFactory;
	private static EntityManager entityManager;
	private static EntityTransaction entityTransaction;
	private static Scanner scanner;
	
	private static void openConnection()
	{
		entityManagerFactory=Persistence.createEntityManagerFactory("car");
		entityManager=entityManagerFactory.createEntityManager();
		entityTransaction=entityManager.getTransaction();
		
	}
	
	private static void closeConnection()
	{
		if (entityManagerFactory!=null) {
			entityManagerFactory.close();
		}
		if (entityManager!=null) {
			entityManager.close();
		}
		if (entityTransaction!=null) {
			if (entityTransaction.isActive()) {
				entityTransaction.rollback();
			}
		}
	}

	public static void addcar() {
		openConnection();
		entityTransaction.begin();
		
		scanner = new Scanner(System.in);
		System.out.println("How many car details"
				+ " you want to add?");
		int choice = scanner.nextInt();
		for (int i = 1; i <= choice ; i++) {
			System.out.println("Enter the details "
					+ "for car " + i);
			
			CarDTO car = new CarDTO();
		
			try {
				System.out.print("Enter car id : ");
				car.setId(scanner.nextInt());
				
				System.out.print("Enter car name : ");
				car.setCname(scanner.next());
				
				System.out.print("Enter car brand : ");
				car.setBrand(scanner.next());
				
				System.out.print("Enter car fuel type : ");
				car.setFuel_type(scanner.next());
				
				System.out.print("Enter car price : ");
				car.setPrice(scanner.nextDouble());
				
				entityManager.persist(car);
				
			} catch (InputMismatchException e) {
				System.out.println("Invalid input! "
						+ "Data not inserted!");
				break;
			}
			
				System.out.println("Car no. " + i + " added. ");
		}
		
		entityTransaction.commit();
		closeConnection();
	}
	
	public static void deleteCar()
	{
		openConnection();
		entityTransaction.begin();
		
		entityTransaction.commit();
		closeConnection();
		
	}
	
	public static void updateCar()
	{
		openConnection();
		entityTransaction.begin();
		
		entityTransaction.commit();
		closeConnection();

	}
	
	
	public static void searchCar()
	{
		openConnection();
		entityTransaction.begin();
		
		try {
			SearchCarDTO car = new SearchCarDTO();

			System.out.print("Enter car name : ");
			Scanner scanner2 = new Scanner(System.in);
			car.setCname(scanner2.next());
			entityManager.persist(car);
			
			while(entityManager.contains(scanner2)) {
				car.setId(scanner2.nextInt(1));
				car.setCname(scanner2.next());
				car.setBrand(scanner2.next());
				car.setFuel_type(scanner2.next());
				car.setPrice(scanner2.nextDouble());
				
				System.out.println(car);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			entityTransaction.commit();
			closeConnection();
		}
	}

	public void searchByBrand() {
		try {
			SearchCarDTO car = new SearchCarDTO();

			System.out.print("Enter car Brand : ");
			Scanner scanner2 = new Scanner(System.in);
			car.setCname(scanner2.next());
			entityManager.persist(car);
			
			while(entityManager.contains(scanner2)) {
				car.setId(scanner2.nextInt(1));
				car.setCname(scanner2.next());
				car.setBrand(scanner2.next());
				car.setFuel_type(scanner2.next());
				car.setPrice(scanner2.nextDouble());
				
				System.out.println(car);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			entityTransaction.commit();
			closeConnection();
		}
	}

	public void searchByFuelType() {
		try {
			
			SearchCarDTO car = new SearchCarDTO();

			System.out.print("Enter car Fule Type : ");
			Scanner scanner2 = new Scanner(System.in);
			car.setCname(scanner2.next());
			entityManager.persist(car);
			
			while(entityManager.contains(scanner2)) {
				car.setId(scanner2.nextInt(1));
				car.setCname(scanner2.next());
				car.setBrand(scanner2.next());
				car.setFuel_type(scanner2.next());
				car.setPrice(scanner2.nextDouble());
				
				System.out.println(car);			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			entityTransaction.commit();
			closeConnection();

		}
	}

		public static void searchByName() {
			
			openConnection();
			entityTransaction.begin();
			
			
			entityTransaction.commit();
			closeConnection();

		}
		public static void getAllCarDetails()
		{
			openConnection();
			entityTransaction.begin();
			
			
			
			entityTransaction.commit();
			closeConnection();

		}
		
		public static void editCarDetails()
		{
			openConnection();
			entityTransaction.begin();
			
			
			
			entityTransaction.commit();
			closeConnection();

		}
}











